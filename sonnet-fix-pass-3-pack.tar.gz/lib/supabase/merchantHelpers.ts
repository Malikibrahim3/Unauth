/**
 * lib/supabase/merchantHelpers.ts
 *
 * Shared, merchant-scoped data access helpers.
 *
 * SECURITY CONTRACT
 * -----------------
 * Every function in this module PROVES merchant ownership before returning data.
 * Callers must not bypass these helpers with raw service-role queries against
 * audit_transactions, customer_profiles, or fraud_identity_clusters.
 *
 * These helpers work with the service-role Supabase client (which bypasses RLS),
 * so they MUST enforce tenant boundaries in application code.
 */

import type { SupabaseClient } from '@supabase/supabase-js';
import { resolveCallerContext } from '@/lib/permissions';
import type { CallerContext } from '@/lib/permissions';

// ---------------------------------------------------------------------------
// Re-export CallerContext so callers don't need to import from two places
// ---------------------------------------------------------------------------
export type { CallerContext };

// ---------------------------------------------------------------------------
// CSV cell escaping — neutralises spreadsheet formula injection
// ---------------------------------------------------------------------------

/**
 * Safely escape a single CSV cell value.
 * - Wraps the value in double-quotes.
 * - Escapes internal double-quotes by doubling them.
 * - Prefixes cells that start with =, +, -, @, TAB, or CR with a single-quote
 *   so spreadsheet applications cannot interpret them as formulas.
 */
export function escapeCsvCell(value: unknown): string {
  const str = value == null ? '' : String(value);
  const FORMULA_CHARS = /^[=+\-@\t\r]/;
  const safe = FORMULA_CHARS.test(str) ? `'${str}` : str;
  return `"${safe.replace(/"/g, '""')}"`;
}

// ---------------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------------

/**
 * Resolves the caller context or throws a 401-style error.
 * Use this inside server components / API routes that already have the
 * authenticated userId.
 */
export async function getCallerContextOrThrow(
  serviceClient: SupabaseClient,
  userId: string
): Promise<CallerContext> {
  const ctx = await resolveCallerContext(serviceClient, userId);
  if (!ctx || !ctx.merchantId) {
    throw Object.assign(new Error('No merchant context found for user'), {
      status: 401,
    });
  }
  return ctx!;
}

// ---------------------------------------------------------------------------
// Processing jobs — merchant ownership proofs
// ---------------------------------------------------------------------------

/**
 * Returns the list of processing_job IDs that belong to the given merchant.
 * Always scope transaction queries with `.in('job_id', ownedJobIds)`.
 */
export async function getMerchantOwnedJobIds(
  serviceClient: SupabaseClient,
  merchantId: string
): Promise<string[]> {
  const { data, error } = await serviceClient
    .from('processing_jobs')
    .select('id')
    .eq('merchant_id', merchantId);

  if (error) throw new Error(`getMerchantOwnedJobIds failed: ${error.message}`);
  return (data ?? []).map((r: { id: string }) => r.id);
}

/**
 * Asserts that a specific job belongs to the given merchant.
 * Throws if the job is not found or belongs to a different merchant.
 */
export async function assertMerchantOwnsJob(
  serviceClient: SupabaseClient,
  merchantId: string,
  jobId: string
): Promise<void> {
  const { data, error } = await serviceClient
    .from('processing_jobs')
    .select('id')
    .eq('id', jobId)
    .eq('merchant_id', merchantId)
    .maybeSingle();

  if (error) throw new Error(`assertMerchantOwnsJob failed: ${error.message}`);
  if (!data) {
    throw Object.assign(
      new Error(`Job ${jobId} not found or does not belong to merchant ${merchantId}`),
      { status: 404 }
    );
  }
}

// ---------------------------------------------------------------------------
// Customer profile helpers
// ---------------------------------------------------------------------------

const PROFILE_SELECT =
  'id, emails, names, phones, addresses, ips, card_last4s, merchant_ids, ' +
  'primary_email, total_orders, total_refund_claims, refund_rate, ' +
  'fastest_claim_days, avg_claim_days, refund_acceleration_score, ' +
  'first_seen, last_seen, identity_signals, fraud_flags, ' +
  'match_status, identity_confidence_grade, identity_score, ' +
  'total_chargebacks, investigation_status, cluster_id';

/**
 * Fetches a customer profile, verifying it belongs to the caller's merchant.
 * Returns null if the profile does not exist or does not belong to the merchant.
 */
export async function fetchMerchantScopedCustomerProfile(
  serviceClient: SupabaseClient,
  merchantId: string,
  profileId: string
): Promise<Record<string, unknown> | null> {
  const { data } = await serviceClient
    .from('customer_profiles')
    .select(PROFILE_SELECT)
    .eq('id', profileId)
    // customer_profiles uses an array column merchant_ids; check both the
    // merchant UUID and, as a legacy fallback, the owner user_id.
    // We do NOT rely solely on this — we also cross-check via job ownership below.
    .contains('merchant_ids', [merchantId])
    .maybeSingle() as unknown as { data: Record<string, unknown> | null };

  return data ?? null;
}

// ---------------------------------------------------------------------------
// Transaction helpers
// ---------------------------------------------------------------------------

export const TX_SAFE_SELECT =
  'id,job_id,order_id,customer_email,customer_name,shipping_address,' +
  'device_ip,card_last4,order_value,match_score,fraud_flags,risk_level,' +
  'identity_confidence_grade,identity_score,match_status,' +
  'refund_claimed,refund_reason,chargeback_filed,chargeback_date,' +
  'chargeback_reason_code,processed_at,cluster_id,signals_matched,' +
  'dismissed_by_merchant';

/**
 * Fetches transactions for a customer profile, constrained to merchant-owned
 * processing jobs. This is the ONLY safe way to fetch customer transactions
 * from a service-role context.
 *
 * Strategy:
 * 1. Get all job IDs owned by the merchant.
 * 2. Fetch audit_appearances for the profile, filtered to those job IDs.
 * 3. Fetch transactions by appearance transaction_ids AND job_id constraint.
 * 4. If not enough rows, widen to all transactions in owned jobs matching the
 *    profile's identity attributes.
 * No fallback query without job_id constraint is ever performed.
 */
export async function fetchMerchantScopedCustomerTransactions(
  serviceClient: SupabaseClient,
  merchantId: string,
  profileId: string,
  profile: Record<string, unknown>,
  options: { select?: string } = {}
): Promise<Array<Record<string, unknown>>> {
  const select = options.select ?? TX_SAFE_SELECT;

  const ownedJobIds = await getMerchantOwnedJobIds(serviceClient, merchantId);
  if (ownedJobIds.length === 0) return [];

  const transactions: Array<Record<string, unknown>> = [];
  const seen = new Set<string>();

  const pushTx = (rows: Array<Record<string, unknown>>) => {
    for (const row of rows) {
      const key = (row.id as string) ?? `${row.order_id}-${row.processed_at}`;
      if (!seen.has(key)) {
        seen.add(key);
        transactions.push(row);
      }
    }
  };

  // Step 1: appearances scoped to owned jobs
  const { data: appearances } = await serviceClient
    .from('customer_profile_audit_appearances')
    .select('audit_id,transaction_id')
    .eq('profile_id', profileId)
    .in('audit_id', ownedJobIds) as unknown as {
      data: Array<{ audit_id: string; transaction_id: string | null }> | null;
    };

  const linkedTxIds = (appearances ?? [])
    .map((a) => a.transaction_id)
    .filter((id): id is string => typeof id === 'string' && id.length > 0);

  // Step 2: fetch by linked transaction IDs, constrained by job ownership
  if (linkedTxIds.length > 0) {
    let offset = 0;
    const PAGE = 1000;
    while (true) {
      const { data: page } = await serviceClient
        .from('audit_transactions')
        .select(select)
        .in('id', linkedTxIds)
        .in('job_id', ownedJobIds)
        .order('processed_at', { ascending: true })
        .range(offset, offset + PAGE - 1) as unknown as {
          data: Array<Record<string, unknown>> | null;
        };
      pushTx(page ?? []);
      if (!page || page.length < PAGE) break;
      offset += PAGE;
    }
  }

  // Step 3: widen to profile identity attributes within owned jobs
  const profileEmails = (profile.emails ?? []) as string[];
  const profileCards = (profile.card_last4s ?? []) as string[];
  const profileIps = (profile.ips ?? []) as string[];

  const primaryIdentifier =
    profileEmails.length > 0
      ? { field: 'customer_email', values: profileEmails }
      : profileCards.length > 0
        ? { field: 'card_last4', values: profileCards }
        : profileIps.length > 0
          ? { field: 'device_ip', values: profileIps }
          : null;

  if (primaryIdentifier) {
    let offset = 0;
    const PAGE = 1000;
    while (true) {
      const { data: page } = await (serviceClient
        .from('audit_transactions')
        .select(select)
        .in('job_id', ownedJobIds)
        .in(primaryIdentifier.field, primaryIdentifier.values)
        .order('processed_at', { ascending: true })
        .range(offset, offset + PAGE - 1) as unknown as Promise<{
          data: Array<Record<string, unknown>> | null;
        }>);
      pushTx(page ?? []);
      if (!page || page.length < PAGE) break;
      offset += PAGE;
    }
  }

  return transactions;
}

/**
 * Fetches a single transaction, verifying it belongs to the given merchant
 * via job_id ownership. Both id and job_id must match.
 */
export async function fetchMerchantScopedTransaction(
  serviceClient: SupabaseClient,
  merchantId: string,
  transactionId: string,
  jobId: string,
  select = '*'
): Promise<Record<string, unknown> | null> {
  // First prove job ownership
  const { data: jobRow } = await serviceClient
    .from('processing_jobs')
    .select('id')
    .eq('id', jobId)
    .eq('merchant_id', merchantId)
    .maybeSingle();

  if (!jobRow) return null;

  const { data } = await serviceClient
    .from('audit_transactions')
    .select(select)
    .eq('id', transactionId)
    .eq('job_id', jobId)
    .maybeSingle() as unknown as { data: Record<string, unknown> | null };

  return data ?? null;
}

// ---------------------------------------------------------------------------
// Generic pagination helper
// ---------------------------------------------------------------------------

/**
 * Paginates a Supabase table query, fetching all rows without a hard cap.
 * Pass a factory function that accepts (from, to) range values.
 *
 * @example
 * const rows = await paginateAll((from, to) =>
 *   serviceClient.from('audit_transactions').select('*')
 *     .in('job_id', jobIds).range(from, to)
 * );
 */
export async function paginateAll<T>(
  queryFactory: (from: number, to: number) => Promise<{ data: T[] | null; error: unknown }>,
  pageSize = 1000
): Promise<T[]> {
  const all: T[] = [];
  let offset = 0;
  while (true) {
    const { data, error } = await queryFactory(offset, offset + pageSize - 1);
    if (error) throw new Error(`paginateAll query failed: ${String(error)}`);
    all.push(...(data ?? []));
    if (!data || data.length < pageSize) break;
    offset += pageSize;
  }
  return all;
}
