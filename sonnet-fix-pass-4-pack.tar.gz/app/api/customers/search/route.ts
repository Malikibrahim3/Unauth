import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { requirePermission, PERMISSIONS } from '@/lib/permissions';

export const dynamic = 'force-dynamic';

/**
 * GET /api/customers/search?q=<query>&limit=<n>
 * Returns matching customer profiles for the command palette.
 *
 * SECURITY: requires authenticated user with VIEW_CUSTOMERS permission.
 * Results are scoped to the caller's merchantId via merchant_ids array membership.
 * No unauthenticated access, no cross-merchant profile exposure.
 */
export async function GET(req: NextRequest) {
  // ── Auth ──────────────────────────────────────────────────────────────────
  const userClient = createClient();
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const serviceClient = createServiceClient();
  const { denied, ctx } = await requirePermission(serviceClient, user.id, PERMISSIONS.VIEW_CUSTOMERS);
  if (denied) return denied;

  // ── Input validation ──────────────────────────────────────────────────────
  const q = req.nextUrl.searchParams.get('q')?.trim() ?? '';
  const limit = Math.min(parseInt(req.nextUrl.searchParams.get('limit') ?? '5', 10), 20);

  if (!q || q.length < 2) {
    return NextResponse.json({ results: [] });
  }

  const like = `%${q}%`;

  // ── Merchant-scoped search ─────────────────────────────────────────────────
  // SECURITY: Always constrain to caller's merchantId via merchant_ids array.
  // This ensures cross-merchant profiles are never returned even though we use
  // a service-role client (which bypasses RLS).
  const { data, error } = await serviceClient
    .from('customer_profiles')
    .select('id, names, primary_email, risk_level')
    .contains('merchant_ids', [ctx.merchantId])
    .or(`primary_email.ilike.${like},names.cs.{${q}}`)
    .order('risk_score', { ascending: false })
    .limit(limit);

  if (error) {
    // Fallback: text search on primary_email only, still merchant-scoped
    const { data: fallback } = await serviceClient
      .from('customer_profiles')
      .select('id, names, primary_email, risk_level')
      .contains('merchant_ids', [ctx.merchantId])
      .ilike('primary_email', like)
      .order('risk_score', { ascending: false })
      .limit(limit);

    const results = (fallback ?? []).map((r: any) => ({
      id: r.id,
      name: r.names?.[0] ?? r.primary_email ?? 'Unknown',
      email: r.primary_email,
      risk_level: r.risk_level ?? 'low',
    }));
    return NextResponse.json({ results });
  }

  const results = (data ?? []).map((r: any) => ({
    id: r.id,
    name: r.names?.[0] ?? r.primary_email ?? 'Unknown',
    email: r.primary_email,
    risk_level: r.risk_level ?? 'low',
  }));

  return NextResponse.json({ results });
}
