/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverComponentsExternalPackages: ['papaparse'],
  },
  // SECURITY: Explicit image optimizer allowlist — mitigates GHSA-9g9p-9gw9-jx7f
  // (Next.js DoS via Image Optimizer remotePatterns).
  // Only the Supabase storage bucket for this project is permitted.
  // No wildcard patterns are allowed. Adding a new origin requires review.
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },
};

module.exports = nextConfig;
