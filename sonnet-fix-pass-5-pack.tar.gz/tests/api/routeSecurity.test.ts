/**
 * tests/api/routeSecurity.test.ts
 *
 * Behavioral route security tests.
 *
 * These tests verify:
 * 1. /api/customers/search — unauthenticated requests return 401
 *    and cross-merchant profiles are never returned.
 * 2. /api/evidence/ce3-check — cross-merchant order IDs return ineligible,
 *    owned orders work correctly.
 * 3. /api/inbox/export — normal rows with match_status='none' are excluded.
 * 4. fetchMerchantReviewQueueRows helper — semantics match definition.
 * 5. Static guard — service-role routes must be auth-gated.
 */

import path from 'path';
import fs from 'fs';
const { globSync } = require('glob');
import {
  fetchMerchantReviewQueueRows,
} from '../../lib/supabase/merchantHelpers';

// ---------------------------------------------------------------------------
// Helper: minimal Supabase mock
// ---------------------------------------------------------------------------
function makeChain(resolveValue: any = { data: [], error: null }) {
  const chain: any = {
    select: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    in: jest.fn().mockReturnThis(),
    not: jest.fn().mockReturnThis(),
    contains: jest.fn().mockReturnThis(),
    or: jest.fn().mockReturnThis(),
    order: jest.fn().mockReturnThis(),
    range: jest.fn().mockResolvedValue(resolveValue),
    limit: jest.fn().mockReturnThis(),
    maybeSingle: jest.fn().mockResolvedValue({ data: null, error: null }),
    single: jest.fn().mockResolvedValue({ data: null, error: null }),
  };
  return chain;
}

// ---------------------------------------------------------------------------
// Static guard: every service-role route must have auth gating
// ---------------------------------------------------------------------------
describe('Static security guard: service-role routes must be auth-gated', () => {
  let routeFiles: string[] = [];

  beforeAll(async () => {
    routeFiles = globSync('app/api/**/route.ts', { cwd: process.cwd() });
  });

  it('finds route files to check', () => {
    expect(routeFiles.length).toBeGreaterThan(0);
  });

  it('every service-role route uses auth.getUser() AND requirePermission()', () => {
    const violations: string[] = [];

    // Explicitly whitelisted routes that are HMAC/internal or PII-free public
    const WHITELIST = [
      'app/api/demo/',
      'app/api/health',
      'app/api/stripe/webhook',
    ];

    for (const relPath of routeFiles) {
      const absPath = path.join(process.cwd(), relPath);
      const content = fs.readFileSync(absPath, 'utf-8');

      const usesServiceRole =
        content.includes('createServiceClient') ||
        content.includes('SUPABASE_SERVICE_ROLE_KEY');

      if (!usesServiceRole) continue;

      const isWhitelisted = WHITELIST.some((w) => relPath.startsWith(w));
      if (isWhitelisted) continue;

      const hasHmacAuth =
        content.includes('HMAC') ||
        content.includes('x-internal-secret') ||
        content.includes('verifyInternalToken') ||
        content.includes('internal-auth');
      if (hasHmacAuth) continue;

      // Standard routes must have BOTH auth.getUser() AND requirePermission()
      const hasUserAuth = content.includes('auth.getUser');
      const hasPermissionCheck = content.includes('requirePermission');

      if (!hasUserAuth || !hasPermissionCheck) {
        violations.push(
          `${relPath} — missing: ${!hasUserAuth ? 'auth.getUser()' : ''}${!hasUserAuth && !hasPermissionCheck ? ' + ' : ''}${!hasPermissionCheck ? 'requirePermission()' : ''}`
        );
      }
    }

    if (violations.length > 0) {
      console.error(
        'Routes using service role WITHOUT full auth+permission gating:\n' +
          violations.map((v) => `  • ${v}`).join('\n')
      );
    }

    expect(violations).toEqual([]);
  });
});

// ---------------------------------------------------------------------------
// /api/customers/search — must require auth
// ---------------------------------------------------------------------------
describe('/api/customers/search — auth requirement', () => {
  it('route file calls auth.getUser() before using service role', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/customers/search/route.ts'),
      'utf-8'
    );
    expect(content).toContain('auth.getUser');
    expect(content).toContain('requirePermission');
    expect(content).toContain('401');
  });

  it('route file uses contains(merchant_ids) to scope results', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/customers/search/route.ts'),
      'utf-8'
    );
    expect(content).toContain("contains('merchant_ids'");
    expect(content).toContain('ctx.merchantId');
  });

  it('route returns 401 when user is null — verified via source analysis', () => {
    // Dynamic import of Next.js route handlers is not supported in Jest.
    // We verify the 401 path via static source inspection.
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/customers/search/route.ts'),
      'utf-8'
    );
    // Must have: auth check that returns 401
    expect(content).toContain('401');
    expect(content).toContain('auth.getUser');
    // Must have: 401 appears before any .from() query call
    const idx401 = content.indexOf('401');
    const firstFromCall = content.indexOf('.from(');
    expect(idx401).toBeGreaterThan(-1);
    expect(firstFromCall).toBeGreaterThan(-1);
    expect(idx401).toBeLessThan(firstFromCall);
  });
});

// ---------------------------------------------------------------------------
// /api/evidence/ce3-check — cross-merchant order is rejected
// ---------------------------------------------------------------------------
describe('/api/evidence/ce3-check — merchant scoping', () => {
  it('route file uses fetchMerchantScopedCustomerProfile', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/evidence/ce3-check/route.ts'),
      'utf-8'
    );
    expect(content).toContain('fetchMerchantScopedCustomerProfile');
  });

  it('route file uses fetchMerchantScopedCustomerTransactions', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/evidence/ce3-check/route.ts'),
      'utf-8'
    );
    expect(content).toContain('fetchMerchantScopedCustomerTransactions');
  });

  it('route file does NOT use .eq(merchant_id) on customer_profiles or audit_transactions', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/evidence/ce3-check/route.ts'),
      'utf-8'
    );
    // Should not have legacy incorrect field usage
    expect(content).not.toContain(".eq('merchant_id', ctx.merchantId)");
    expect(content).not.toContain('.limit(500)');
  });

  it('cross-merchant order ID returns ineligible — order not in merchant transactions', () => {
    // fetchMerchantScopedCustomerTransactions returns no rows for other-merchant orders.
    // The route checks disputedTx = txRows.find(tx => tx.id === orderId)
    // If not found, it returns eligible: false with a clear reason.
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/evidence/ce3-check/route.ts'),
      'utf-8'
    );
    expect(content).toContain('Disputed order not found in merchant account');
  });
});

// ---------------------------------------------------------------------------
// fetchMerchantReviewQueueRows — review queue semantics
// ---------------------------------------------------------------------------
describe('fetchMerchantReviewQueueRows — review queue definition', () => {
  it('returns empty when merchant has no jobs', async () => {
    const mock = {
      from: jest.fn((table: string) => {
        const c = makeChain({ data: [], error: null });
        c.eq = jest.fn().mockResolvedValue({ data: [], error: null });
        return c;
      }),
    };

    const result = await fetchMerchantReviewQueueRows(mock as any, 'merchant-no-jobs');
    expect(result.rows).toEqual([]);
    expect(result.ownedJobIds).toEqual([]);
  });

  it('query includes .or() for identity_confidence_grade or match_status', async () => {
    const orCalls: string[] = [];
    const inCalls: [string, string[]][] = [];
    const notCalls: [string, string, unknown][] = [];

    const mock = {
      from: jest.fn((table: string) => {
        if (table === 'processing_jobs') {
          const c = makeChain();
          c.eq = jest.fn().mockResolvedValue({ data: [{ id: 'job-1' }], error: null });
          return c;
        }
        // audit_transactions
        const c: any = {
          select: jest.fn().mockReturnThis(),
          in: jest.fn((col: string, val: string[]) => { inCalls.push([col, val]); return c; }),
          or: jest.fn((expr: string) => { orCalls.push(expr); return c; }),
          not: jest.fn((col: string, op: string, val: unknown) => { notCalls.push([col, op, val]); return c; }),
          order: jest.fn().mockReturnThis(),
          range: jest.fn().mockResolvedValue({ data: [], error: null }),
        };
        return c;
      }),
    };

    await fetchMerchantReviewQueueRows(mock as any, 'merchant-abc');

    // Verify job_id constraint is applied
    const jobIdIn = inCalls.find(([col]) => col === 'job_id');
    expect(jobIdIn).toBeDefined();
    expect(jobIdIn![1]).toContain('job-1');

    // Verify or() for identity_confidence_grade and match_status
    const hasIdentityOr = orCalls.some(
      (expr) =>
        expr.includes('identity_confidence_grade') &&
        expr.includes('match_status')
    );
    expect(hasIdentityOr).toBe(true);

    // Verify dismissed_by_merchant is excluded
    const dismissedNot = notCalls.find(([col]) => col === 'dismissed_by_merchant');
    expect(dismissedNot).toBeDefined();

    // Verify match_status='none' is NOT excluded via a separate .not() call
    // (that would drop null match_status rows). The .or() expression handles
    // exclusion implicitly.
    const noneNot = notCalls.find(([col, , val]) => col === 'match_status' && val === 'none');
    expect(noneNot).toBeUndefined();
  });

  it('normal rows with match_status=none are excluded by .or() semantics, not a .not() filter', async () => {
    // CORRECTNESS: we must NOT use .not('match_status','eq','none') because that
    // operator excludes NULLs too (breaking graded rows with null match_status).
    // Instead, the .or() expression only includes candidate/probable/definite/graded rows.
    const notCalls: [string, string, unknown][] = [];

    const mock = {
      from: jest.fn((table: string) => {
        if (table === 'processing_jobs') {
          const c = makeChain();
          c.eq = jest.fn().mockResolvedValue({ data: [{ id: 'job-1' }], error: null });
          return c;
        }
        const c: any = {
          select: jest.fn().mockReturnThis(),
          in: jest.fn().mockReturnThis(),
          or: jest.fn().mockReturnThis(),
          not: jest.fn((col: string, op: string, val: unknown) => { notCalls.push([col, op, val]); return c; }),
          order: jest.fn().mockReturnThis(),
          range: jest.fn().mockResolvedValue({ data: [], error: null }),
        };
        return c;
      }),
    };

    await fetchMerchantReviewQueueRows(mock as any, 'merchant-abc');

    // Must NOT have a .not('match_status', ...) that would drop null rows
    const hasMatchStatusNot = notCalls.some(([col]) => col === 'match_status');
    expect(hasMatchStatusNot).toBe(false);
  });

  it('orders by identity_score DESC, then processed_at DESC — not match_score', async () => {
    const orderCalls: [string, { ascending: boolean }][] = [];

    const mock = {
      from: jest.fn((table: string) => {
        if (table === 'processing_jobs') {
          const c = makeChain();
          c.eq = jest.fn().mockResolvedValue({ data: [{ id: 'job-1' }], error: null });
          return c;
        }
        const c: any = {
          select: jest.fn().mockReturnThis(),
          in: jest.fn().mockReturnThis(),
          or: jest.fn().mockReturnThis(),
          not: jest.fn().mockReturnThis(),
          order: jest.fn((col: string, opts: { ascending: boolean }) => { orderCalls.push([col, opts]); return c; }),
          range: jest.fn().mockResolvedValue({ data: [], error: null }),
        };
        return c;
      }),
    };

    await fetchMerchantReviewQueueRows(mock as any, 'merchant-abc');

    const cols = orderCalls.map(([col]) => col);
    expect(cols).toContain('identity_score');
    expect(cols).not.toContain('match_score');
    // identity_score must be descending
    const scoreOrder = orderCalls.find(([col]) => col === 'identity_score');
    expect(scoreOrder![1].ascending).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// /api/inbox/export — correct population semantics
// ---------------------------------------------------------------------------
describe('/api/inbox/export — review population semantics', () => {
  it('export route uses fetchMerchantReviewQueueRows', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/inbox/export/route.ts'),
      'utf-8'
    );
    expect(content).toContain('fetchMerchantReviewQueueRows');
  });

  it('export route does NOT use legacy match_score ordering', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/inbox/export/route.ts'),
      'utf-8'
    );
    expect(content).not.toContain("order('match_score'");
  });

  it('export route does NOT use legacy risk_level filter', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/inbox/export/route.ts'),
      'utf-8'
    );
    expect(content).not.toContain("in('risk_level'");
    expect(content).not.toContain("risk_level");
  });
});

// ---------------------------------------------------------------------------
// Inbox page — correct population semantics
// ---------------------------------------------------------------------------
describe('Inbox page — review population semantics', () => {
  it('inbox page uses fetchMerchantReviewQueueRows', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).toContain('fetchMerchantReviewQueueRows');
  });

  it('inbox page does NOT filter by legacy risk_level', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).not.toContain("in('risk_level'");
    expect(content).not.toContain("risk_level: ['high'");
  });

  it('inbox page does NOT order by legacy match_score', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).not.toContain("order('match_score'");
  });

  it('inbox page uses service client with requirePermission', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).toContain('requirePermission');
    expect(content).toContain('createServiceClient');
  });
});

// ---------------------------------------------------------------------------
// Customer page — no global fraud_identity_clusters reads
// ---------------------------------------------------------------------------
describe('Customer detail page — linked identity privacy', () => {
  it('does NOT read from fraud_identity_clusters', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/customers/[id]/page.tsx'),
      'utf-8'
    );
    // The table must not appear in any .from() call
    expect(content).not.toMatch(/\.from\s*\(\s*['"]fraud_identity_clusters['"]/);
  });

  it('derives linked identity from merchant-owned transactions only', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/customers/[id]/page.tsx'),
      'utf-8'
    );
    // Must use fetchMerchantScopedCustomerTransactions (not raw cluster table)
    expect(content).toContain('fetchMerchantScopedCustomerTransactions');
    expect(content).not.toContain('getMerchantOwnedJobIds');
  });
});

// ---------------------------------------------------------------------------
// escapePostgrestFilterValue — hostile input sanitisation
// ---------------------------------------------------------------------------
import { escapePostgrestFilterValue } from '../../lib/supabase/merchantHelpers';

describe('escapePostgrestFilterValue — hostile input handling', () => {
  it('passes through safe alphanumeric input unchanged', () => {
    expect(escapePostgrestFilterValue('john.doe@example.com')).toBe('john.doe@example.com');
    expect(escapePostgrestFilterValue('Alice Smith')).toBe('Alice Smith');
    expect(escapePostgrestFilterValue('test123')).toBe('test123');
  });

  it('escapes commas (PostgREST .or() delimiter)', () => {
    const result = escapePostgrestFilterValue('a,b');
    expect(result).not.toContain(',');
    expect(result).toContain('%2C');
  });

  it('escapes parentheses (PostgREST grouping chars)', () => {
    const result = escapePostgrestFilterValue('(inject)');
    expect(result).not.toContain('(');
    expect(result).not.toContain(')');
  });

  it('escapes curly braces (PostgREST array literal chars)', () => {
    const result = escapePostgrestFilterValue('{bad}');
    expect(result).not.toContain('{');
    expect(result).not.toContain('}');
  });

  it('escapes double quotes', () => {
    const result = escapePostgrestFilterValue('"quoted"');
    expect(result).not.toContain('"');
  });

  it('escapes single quotes', () => {
    const result = escapePostgrestFilterValue("o'malley");
    expect(result).not.toContain("'");
  });

  it('escapes percent signs (LIKE wildcard overflow)', () => {
    const result = escapePostgrestFilterValue('100% legit');
    // % is encoded as %25, so no bare unencoded % remains
    expect(result).toContain('%25');
    expect(result).not.toContain('% ');  // no literal '% ' (space after %)
    // The original input '100% legit' has been encoded
    expect(result).not.toBe('100% legit');
  });

  it('escapes backslashes', () => {
    const result = escapePostgrestFilterValue('C:\\path');
    expect(result).not.toContain('\\');
  });

  it('removes null bytes', () => {
    const result = escapePostgrestFilterValue('bad\0byte');
    expect(result).not.toContain('\0');
    expect(result).toBe('badbyte');
  });

  it('handles combined hostile input without throwing', () => {
    const hostile = '\'"();{}%\\test\0inject';
    expect(() => escapePostgrestFilterValue(hostile)).not.toThrow();
    const result = escapePostgrestFilterValue(hostile);
    // Raw literal special chars are gone (encoded as %XX sequences)
    expect(result).not.toContain('(');
    expect(result).not.toContain(')');
    expect(result).not.toContain("'");
    expect(result).not.toContain('\\');
    // % is allowed only as part of a %XX percent-encoding sequence
    expect(result).not.toMatch(/%(?![0-9A-Fa-f]{2})/);
  });
});

// ---------------------------------------------------------------------------
// Review queue helper — regression: graded rows with null match_status
// ---------------------------------------------------------------------------
describe('fetchMerchantReviewQueueRows — null match_status regression', () => {
  it('does NOT add .not(match_status, eq, none) filter that would drop null rows', () => {
    // Static check: the helper source must not call .not('match_status', 'eq', 'none')
    // because PostgREST not.eq excludes NULLs, silently dropping legacy graded rows.
    const helperContent = fs.readFileSync(
      path.join(process.cwd(), 'lib/supabase/merchantHelpers.ts'),
      'utf-8'
    );
    // Must not contain the problematic filter
    expect(helperContent).not.toContain(".not('match_status', 'eq', 'none')");
    expect(helperContent).not.toContain('.not("match_status", "eq", "none")');
  });

  it('graded row with null match_status passes inclusion filter via or() expression', async () => {
    // A row with identity_confidence_grade='B' and match_status=null
    // must be included. The .or() expression checks grade NOT NULL first,
    // so null match_status is irrelevant for inclusion.
    const orCalls: string[] = [];
    const mock = {
      from: jest.fn((table: string) => {
        if (table === 'processing_jobs') {
          const c = makeChain();
          c.eq = jest.fn().mockResolvedValue({ data: [{ id: 'job-1' }], error: null });
          return c;
        }
        const c: any = {
          select: jest.fn().mockReturnThis(),
          in: jest.fn().mockReturnThis(),
          or: jest.fn((expr: string) => { orCalls.push(expr); return c; }),
          not: jest.fn().mockReturnThis(),
          order: jest.fn().mockReturnThis(),
          // Simulate DB returning a graded row with null match_status
          range: jest.fn().mockResolvedValue({
            data: [{ id: 'tx-1', identity_confidence_grade: 'B', match_status: null }],
            error: null,
          }),
        };
        return c;
      }),
    };

    const { rows } = await fetchMerchantReviewQueueRows(mock as any, 'merchant-abc');

    // Row must be returned (it passes the .or() filter on the DB side)
    expect(rows).toHaveLength(1);
    expect(rows[0].identity_confidence_grade).toBe('B');
    expect(rows[0].match_status).toBeNull();

    // The .or() expression must include identity_confidence_grade check
    const hasGradeOr = orCalls.some((expr) => expr.includes('identity_confidence_grade'));
    expect(hasGradeOr).toBe(true);
  });

  it('row with match_status=none and null grade is excluded by .or() semantics', () => {
    // Static: the or() filter only includes rows where grade IS NOT NULL
    // OR match_status IN (candidate,probable,definite).
    // A row with match_status='none' and null grade satisfies neither condition,
    // so it is excluded by the DB query. We verify the filter expression is correct.
    const helperContent = fs.readFileSync(
      path.join(process.cwd(), 'lib/supabase/merchantHelpers.ts'),
      'utf-8'
    );
    // Must include the correct PostgREST .or() expression
    expect(helperContent).toContain('identity_confidence_grade.not.is.null');
    expect(helperContent).toContain('match_status.in.(candidate,probable,definite)');
  });

  it('dismissed rows are excluded via .not(dismissed_by_merchant, is, true)', () => {
    const helperContent = fs.readFileSync(
      path.join(process.cwd(), 'lib/supabase/merchantHelpers.ts'),
      'utf-8'
    );
    expect(helperContent).toContain("'dismissed_by_merchant'");
    expect(helperContent).toContain('is');
    expect(helperContent).toContain('true');
  });
});

// ---------------------------------------------------------------------------
// Inbox page auth and permission guards
// ---------------------------------------------------------------------------
describe('Inbox page — auth and permission guards', () => {
  it('inbox page redirects unauthenticated users to /login', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).toContain("redirect('/login')");
    // Must redirect BEFORE calling fetchMerchantReviewQueueRows — slice from the
    // function body so we don't confuse the import line with the actual call.
    const fnStart = content.indexOf('export default async function');
    const body = content.slice(fnStart);
    const redirectIdx = body.indexOf("redirect('/login')");
    const fetchIdx = body.indexOf('fetchMerchantReviewQueueRows(');
    expect(redirectIdx).toBeGreaterThan(-1);
    expect(fetchIdx).toBeGreaterThan(-1);
    expect(redirectIdx).toBeLessThan(fetchIdx);
  });

  it('inbox page uses VIEW_INBOX permission, not VIEW_CUSTOMERS', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    expect(content).toContain('PERMISSIONS.VIEW_INBOX');
    expect(content).not.toContain('PERMISSIONS.VIEW_CUSTOMERS');
  });

  it('inbox page returns denied response rather than silently rendering empty queue', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/(app)/inbox/page.tsx'),
      'utf-8'
    );
    // Must have: if (denied) return denied
    expect(content).toContain('if (denied) return denied');
    // Must NOT have: if (!denied) { ... all data loading ... }
    // (silently empty on denial)
    expect(content).not.toContain('if (!denied)');
  });
});

// ---------------------------------------------------------------------------
// Lookup/remaining route — must use requirePermission and ctx.merchantId
// ---------------------------------------------------------------------------
describe('/api/lookup/remaining — permission and merchant scoping', () => {
  it('route uses requirePermission with LOOKUP_CUSTOMER', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/lookup/remaining/route.ts'),
      'utf-8'
    );
    expect(content).toContain('requirePermission');
    expect(content).toContain('PERMISSIONS.LOOKUP_CUSTOMER');
  });

  it('route uses ctx.merchantId, not user.id, for quota scoping', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'app/api/lookup/remaining/route.ts'),
      'utf-8'
    );
    expect(content).toContain('ctx.merchantId');
    // merchant_id column must be scoped by ctx.merchantId, not user.id
    expect(content).not.toContain(".eq('merchant_id', user.id)");
    expect(content).not.toContain('.eq("merchant_id", user.id)');
  });
});

// ---------------------------------------------------------------------------
// images.remotePatterns — mitigation must be real in next.config.js
// ---------------------------------------------------------------------------
describe('next.config.js — image optimizer DoS mitigation', () => {
  it('defines images.remotePatterns (not just experimental config)', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'next.config.js'),
      'utf-8'
    );
    expect(content).toContain('remotePatterns');
    expect(content).toContain('images');
  });

  it('does not use a wildcard remotePatterns hostname', () => {
    const content = fs.readFileSync(
      path.join(process.cwd(), 'next.config.js'),
      'utf-8'
    );
    // Must not allow all hostnames with **
    expect(content).not.toContain("hostname: '**'");
    expect(content).not.toContain('hostname: "*"');
  });
});
