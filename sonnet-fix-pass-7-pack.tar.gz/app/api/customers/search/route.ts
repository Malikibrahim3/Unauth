import { NextRequest, NextResponse } from 'next/server';
import { createClient, createServiceClient } from '@/lib/supabase/server';
import { requirePermission, PERMISSIONS } from '@/lib/permissions';
import { escapePostgrestFilterValue } from '@/lib/supabase/merchantHelpers';

export const dynamic = 'force-dynamic';

/**
 * GET /api/customers/search?q=<query>&limit=<n>
 * Returns matching customer profiles for the command palette.
 *
 * SECURITY: requires authenticated user with VIEW_CUSTOMERS permission.
 * Results are scoped to the caller's merchantId via merchant_ids array membership.
 * No unauthenticated access, no cross-merchant profile exposure.
 */
export async function GET(req: NextRequest) {
  // ── Auth ──────────────────────────────────────────────────────────────────
  const userClient = createClient();
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const serviceClient = createServiceClient();
  const { denied, ctx } = await requirePermission(serviceClient, user.id, PERMISSIONS.VIEW_CUSTOMERS);
  if (denied) return denied;

  // ── Input validation ──────────────────────────────────────────────────────
  const q = req.nextUrl.searchParams.get('q')?.trim() ?? '';
  const limit = Math.min(parseInt(req.nextUrl.searchParams.get('limit') ?? '5', 10), 20);

  if (!q || q.length < 2) {
    return NextResponse.json({ results: [] });
  }

  // Escape user input to prevent PostgREST filter injection via special chars.
  const safeQ = escapePostgrestFilterValue(q);
  const safeLike = `%${safeQ}%`;

  // ── Merchant-scoped search ─────────────────────────────────────────────────
  // SECURITY: Always constrain to caller's merchantId via merchant_ids array.
  // Use separate typed query methods instead of composing a raw .or() string
  // to eliminate PostgREST filter-string injection.
  const emailRes = await serviceClient
    .from('customer_profiles')
    .select('id, names, primary_email, risk_level')
    .contains('merchant_ids', [ctx.merchantId])
    .ilike('primary_email', safeLike)
    .order('risk_score', { ascending: false })
    .limit(limit);

  const nameRes = await serviceClient
    .from('customer_profiles')
    .select('id, names, primary_email, risk_level')
    .contains('merchant_ids', [ctx.merchantId])
    .contains('names', [q])
    .order('risk_score', { ascending: false })
    .limit(limit);

  // Merge and deduplicate by id
  const seen = new Set<string>();
  const merged: Array<{ id: string; names: string[] | null; primary_email: string | null; risk_level: string | null }> = [];
  for (const row of [...(emailRes.data ?? []), ...(nameRes.data ?? [])]) {
    const r = row as { id: string; names: string[] | null; primary_email: string | null; risk_level: string | null };
    if (!seen.has(r.id)) {
      seen.add(r.id);
      merged.push(r);
    }
  }

  if (emailRes.error && nameRes.error) {
    // Double fallback: email ilike only, already escaped above
    const { data: fallback } = await serviceClient
      .from('customer_profiles')
      .select('id, names, primary_email, risk_level')
      .contains('merchant_ids', [ctx.merchantId])
      .ilike('primary_email', safeLike)
      .order('risk_score', { ascending: false })
      .limit(limit);

    const results = (fallback ?? []).map((r: any) => ({
      id: r.id,
      name: r.names?.[0] ?? r.primary_email ?? 'Unknown',
      email: r.primary_email,
      risk_level: r.risk_level ?? 'low',
    }));
    return NextResponse.json({ results });
  }

  const results = merged.slice(0, limit).map((r) => ({
    id: r.id,
    name: r.names?.[0] ?? r.primary_email ?? 'Unknown',
    email: r.primary_email,
    risk_level: r.risk_level ?? 'low',
  }));

  return NextResponse.json({ results });
}
