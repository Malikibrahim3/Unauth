import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const outDir = path.join(root, 'reports/deployment-readiness/benchmarks');
fs.mkdirSync(outDir, { recursive: true });

const includeExt = new Set(['.ts', '.tsx', '.js', '.mjs', '.sql']);
const skip = new Set(['node_modules', '.next', '.git', 'test-results']);

function walk(dir, files = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skip.has(entry.name)) continue;
    if (entry.name.startsWith('.tmp')) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, files);
    else if (includeExt.has(path.extname(entry.name))) files.push(full);
  }
  return files;
}

const checks = [
  { id: 'service-role', pattern: /SUPABASE_SERVICE_ROLE_KEY|createServiceClient|createAdminClient/g },
  { id: 'unsafe-html', pattern: /dangerouslySetInnerHTML|innerHTML\s*=|eval\s*\(|new Function/g },
  { id: 'csv-export', pattern: /Content-Disposition|text\/csv|download/g },
  { id: 'banned-language', pattern: /\bfraudster\b|\bguilty\b|confirmed fraud|fraud confirmed|deny claim|probable fraud|possible fraud/gi },
  { id: 'broad-select', pattern: /select\(['"`]\*['"`]/g },
  { id: 'fixed-limit', pattern: /\.limit\((1000|10000)\)/g },
];

const findings = [];
for (const file of walk(root)) {
  const rel = path.relative(root, file);
  const text = fs.readFileSync(file, 'utf8');
  const lines = text.split(/\r?\n/);
  for (const check of checks) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      check.pattern.lastIndex = 0;
      if (check.pattern.test(line)) {
        findings.push({
          check: check.id,
          file: rel,
          line: i + 1,
          text: line.trim().slice(0, 220),
        });
      }
    }
  }
}

const grouped = findings.reduce((acc, f) => {
  acc[f.check] = (acc[f.check] ?? 0) + 1;
  return acc;
}, {});

fs.writeFileSync(path.join(outDir, 'security-static-scan.json'), `${JSON.stringify({ grouped, findings }, null, 2)}\n`);
console.log(JSON.stringify({ grouped, totalFindings: findings.length }, null, 2));
