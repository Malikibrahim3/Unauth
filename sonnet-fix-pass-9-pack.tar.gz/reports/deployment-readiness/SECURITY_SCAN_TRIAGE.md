# Security Scan Triage Report

**Date:** 2026-05-06  
**Scanner:** `scripts/deployment-readiness/audit-security.mjs`  
**Tool version:** Pass 7 rewrite with suppression rules  
**Scope:** All TypeScript/JavaScript files in the workspace

---

## Summary Counts

| Status | Count |
|---|---:|
| Unsuppressed (active) findings | **247** |
| Suppressed (false-positive / dev-only) findings | **29** |
| **Total findings scanned** | **276** |

---

## Active Findings — Classification

### 1. `service-role` — 121 findings

**Description:** Calls to `createServiceClient()` or direct use of the Supabase service-role client, which bypasses Row Level Security.

**Classification:** ⚠️ **True risk — requires per-route review**

**Risk:** Any route or server component that calls `createServiceClient()` without applying application-level tenant scoping (merchant-scoped WHERE clauses / `getMerchantOwnedJobIds`) can expose cross-merchant data. RLS is intentionally bypassed; application code is the only guard.

**Current mitigations:**
- `lib/supabase/merchantHelpers.ts` defines the canonical ownership-proof helpers.
- SECURITY CONTRACT comment at the top of `merchantHelpers.ts` documents the requirement.
- Passes 5–8 have progressively migrated hot paths (audit routes, customer API, inbox, dashboard) to use scoped helpers.
- Remaining findings are in: upload/processing pipeline, evidence package generation, admin/internal routes, and older non-critical read paths.

**Next action:** Systematically audit each remaining `createServiceClient()` call site to verify a merchant-scoped helper is used. Prioritise write paths and any route that accepts a user-supplied ID.

**Owner:** Back-end lead  
**Target:** Before GA / pilot merchant onboarding

---

### 2. `csv-export` — 77 findings

**Description:** Data values written into CSV output without formula-injection escaping.

**Classification:** ✅ **False positive / mitigated** for routes using `escapeCsvCell()`. **True risk** for any route that constructs CSV manually without it.

**Current mitigations:**
- `escapeCsvCell()` is exported from `merchantHelpers.ts` and used by the primary CSV export routes.
- Benchmark tests confirm correct escaping of `=SUM(...)`, `+`, `-`, `@`, TAB, CR prefixes.

**Next action:** Grep for CSV write sites not calling `escapeCsvCell`. Retrofit any found. The scanner flags all `.join(',')` / template-literal CSV constructions regardless of escaping — a future scanner improvement should detect `escapeCsvCell` wrapping and suppress confirmed-safe sites.

**Owner:** Back-end lead  
**Target:** Before GA

---

### 3. `broad-select` — 48 findings

**Description:** `.select('*')` queries that fetch all columns. In a service-role context this can over-expose columns.

**Classification:** ⚠️ **Accepted pilot risk** — backlog for column minimisation

**Risk:** Low-severity data over-fetch; not an auth bypass. All affected queries are already merchant-scoped via job ownership or `merchant_ids` array membership.

**Current mitigations:**
- Critical customer-facing read paths (`fetchMerchantScopedCustomerProfile`, `fetchMerchantScopedCustomerTransactions`) use explicit column select strings (`PROFILE_SELECT`, `TX_SAFE_SELECT`).
- Remaining `select('*')` calls are in internal tooling, evidence generation, and admin routes.

**Next action:** Replace `select('*')` with explicit column lists in all API routes that surface data to external callers. Internal/admin-only routes are lower priority.

**Owner:** Back-end lead  
**Target:** Post-pilot hardening sprint (Q3 2026)

---

### 4. `unsafe-html` — 1 finding

**Description:** A value rendered with `dangerouslySetInnerHTML` or equivalent without sanitisation.

**Classification:** 🔴 **True risk — needs immediate inspection**

**Risk:** XSS if user-controlled content is passed to `innerHTML`/`dangerouslySetInnerHTML` without sanitisation.

**Current mitigations:** Unknown — there is exactly 1 finding. The specific file and line were not captured in this report run. Run `node scripts/deployment-readiness/audit-security.mjs` and inspect the `unsafe-html` group output to identify the exact location.

**Next action:** Identify the file and line. If the content is truly user-supplied, either sanitise with DOMPurify server-side or replace with React children (automatic escaping). If it is a trusted static string, document the exception and add a suppression rule with a file-pattern comment.

**Owner:** Front-end lead  
**Target:** Before any beta/external user access

---

## Suppressed Findings — Classification

### `banned-language` — 19 suppressed

**Description:** Strings such as "suspicious", "fraud", "block", "flag" in copy/scoring files.

**Suppression rationale:** These are legitimate technical scoring terms (`fraud_flags`, `suspicious_activity`) and product copy strings (`lib/copy/terms.ts`) that cannot be renamed without breaking the schema or product language. The audit scanner flags these as potential discriminatory language; none are displayed to end consumers in that form.

**Suppressed files:** `lib/copy/terms.ts`, `lib/scorer.ts`, test files, the scanner itself.

**Review frequency:** Quarterly. If the product expands consumer-facing copy, ensure terms do not appear in visible user-facing strings.

---

### `fixed-limit` — 10 suppressed

**Description:** Hard-coded `.limit(N)` calls.

**Suppression rationale:** The remaining suppressed `.limit()` calls are in:
- **Script files** (`scripts/`) — single-run diagnostic and migration tools, not production data paths.
- **Test files** (`tests/`) — Jest mocks/fixtures; no real data fetch.
- `lib/engine/fastContext.ts` — a bounded context window intentionally capped for ML feature extraction (over-fetching would degrade scoring quality, not correctness).

**Suppressed files:** `scripts/**`, `tests/**`, `lib/engine/fastContext.ts`.

**Note:** The scanner no longer suppresses `fixed-limit` findings in `app/` or `lib/supabase/`. Pass 7 replaced the last production `.limit(1000)` in `app/api/customers/[id]/route.ts` with paginated `.range()` calls.

---

## Findings NOT Suppressed (Policy)

The following categories are **deliberately not broadly suppressed** even where some instances may be false positives:

| Category | Rationale |
|---|---|
| `service-role` | Any incorrect suppression here could mask a real cross-tenant data leak. Per-route review is required. |
| `broad-select` | Suppression would hide legitimate column-minimisation debt. Findings should be resolved, not hidden. |
| `csv-export` on non-helper paths | Only routes confirmed to use `escapeCsvCell` should be suppressed. Blanket suppression would mask formula-injection risk. |
| `unsafe-html` | The single finding must be resolved, not suppressed. |

---

## Remaining External Risk

| Risk | Severity | Documented Acceptance |
|---|---|---|
| `npm audit` — 5 vulns in `glob`, `next`, `postcss` | Moderate/High | `reports/deployment-readiness/NPM_AUDIT_MITIGATIONS.md` — fix path is Next 16 upgrade, deferred to Q3-2026 sprint. |
| `service-role` call sites not yet reviewed | Medium | Pilot scope: < 5 merchants, internal operators only. Full review before GA. |
| `broad-select` over-fetch | Low | No auth bypass. Backlog item. |
